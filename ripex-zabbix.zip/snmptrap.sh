#!/usr/bin/bash
# Version: 2.6, CentOS7, Zabbix 4.0.3 (2019-01-08)
# Last change: quick verification after Zabbix upgrade
#
# RipEX FW: 			1.8.2.x beta
# RAy FW: 			1.1.17.0, 4.1.51.0
# RAy2 FW: 			2.1.8.0
# MG102i, MIDGE, MIDGE2 FW: 	4.2.40.101

# CONFIGURATION
ZABBIX_SERVER="localhost";
ZABBIX_PORT="10051";
ZABBIX_SENDER="/usr/bin/zabbix_sender";
KEY="snmptraps";
NUMBER_OF_VARS=2;
LOGFILE=/var/log/snmptrap/snmptrap.log
# END OF CONFIGURATION

# define several variables
read host	# example: 192.168.131.231
read udp	# example: UDP: [192.168.131.231]:2049->[10.15.16.118]
read uptime	# example: iso.3.6.1.2.1.1.3.0 0:1:13:37.39
read trapOid 	# example: iso.3.6.1.6.3.1.1.4.1.0 iso.3.6.1.4.1.33555.2.10.7
read alarm	# example: iso.3.6.1.4.1.33555.2.5.2.7 1
read value	# example: iso.3.6.1.4.1.33555.2.4.1.10 38300
read ipOrPn	# example: iso.3.6.1.4.1.33555.2.4.3.1.2 "10.10.10.50"
read bpGw	# example: iso.3.6.1.4.1.33555.2.6.2.1.5 "10.10.10.205"
read altPS	# example: iso.3.6.1.4.1.33555.2.6.2.1.6 2

# LOGGING TRAP INFO
echo "Logging TRAP:" >> ${LOGFILE}
host=`echo $udp | cut -f2 -d'[' | cut -f1 -d']'`
echo "Host: $host" >> ${LOGFILE}

# Uncomment these lines if you need the detailed information about the received trap
echo "UDP: $udp" >> ${LOGFILE}
echo "uptime: $uptime" >> ${LOGFILE}
echo "trap: $trapOid" >> ${LOGFILE}
echo "alarm: $alarm" >> ${LOGFILE}
echo "value: $value" >> ${LOGFILE}
echo "ipOrPn: $ipOrPn" >> ${LOGFILE}
echo "bpGw: $bpGw" >> ${LOGFILE}
echo "altPS: $altPS" >> ${LOGFILE}

# Trap OID, Item OID and Trap OID but only with digits from 33555 identifier
trapTmp=`echo $trapOid|cut -f2 -d' '`
racomTrapOid=`echo $trapTmp|cut -f8- -d'.'`

# alarm
alarmOid=`echo $alarm|cut -f1 -d' '|cut -f8- -d'.'`
alarmValue=`echo $alarm|cut -f2 -d' '`

# value
wvOid=`echo $value|cut -f1 -d' '|cut -f8- -d'.'`
wvValue=`echo $value|cut -f2 -d' '`

# Remote IP or Priority number
if [ -n "$ipOrPn" ]; then
	# DQ, RSS or Backup paths
	ipOrPnOid=`echo $ipOrPn|cut -f1 -d' '|cut -f7- -d'.'`
	ipOrPnValue=`echo $ipOrPn|cut -f2 -d' '`
	let "NUMBER_OF_VARS += 1";
fi

if [ -n "$bpGw" ]; then
	# Backup paths
	bpGwOid=`echo $bpGw|cut -f1 -d' '|cut -f7- -d'.'`
	bpGwValue=`echo $bpGw|cut -f2 -d' '`
	altPSOid=`echo $altPS|cut -f1 -d' '|cut -f7- -d'.'`
	altPSValue=`echo $altPS|cut -f2 -d' '`
	let "NUMBER_OF_VARS += 2";
fi

# Time 
uptime=`echo $uptime|cut -f2 -d ' '`

# Uncomment these lines if you need the detailed information about the received trap
echo "racomTrapOid: $racomTrapOid" >> ${LOGFILE}
echo "alarmOid: $alarmOid" >> ${LOGFILE}
echo "alarmValue: $alarmValue" >> ${LOGFILE}
echo "wvOid: $wvOid" >> ${LOGFILE}
echo "wvValue: $wvValue" >> ${LOGFILE}
echo "ipOrPnOid: $ipOrPnOid" >> ${LOGFILE}
echo "ipOrPnValue: $ipOrPnValue" >> ${LOGFILE}

# Do NOT use it until you solve SELinux MySQL rights
# MySQL - get the right HOST according to Zabbix configuration
# export HOME=/root
# ZABBIXHOST=$(echo "select host from zabbix.hosts where host=\"$host\" order by 'hostid' limit 1;" | mysql -N -uroot -pz4bb1x 2> /dev/null) 
# [[ "$ZABBIXHOST" ]] && HOST=$ZABBIXHOST

# declare an array with the TRAP text descriptions - RipEX
declare -A oid2desc

# RipEX
oid2desc[33555.2.10.1]="RipEX::trpRss - Remote station RSS value out of range"
oid2desc[33555.2.10.2]="RipEX::trpDq - Remote station DQ value out of range"
oid2desc[33555.2.10.5]="RipEX::trpTxLost - TX Lost value out of range"
oid2desc[33555.2.10.6]="RipEX::trpUcc - UCC value out of range"
oid2desc[33555.2.10.7]="RipEX::trpTemp - Modem temperature value out of range"
oid2desc[33555.2.10.8]="RipEX::trpRfpwr - RF power value out of range"
oid2desc[33555.2.10.9]="RipEX::trpVswr - VSWR value out of range"
oid2desc[33555.2.10.10]="RipEX::trpEthPr - Ethernet Rx/Tx packet ratio out of range"
oid2desc[33555.2.10.11]="RipEX::trpCom1Pr - COM1 Rx/Tx packet ratio out of range"
oid2desc[33555.2.10.12]="RipEX::trpCom2Pr - COM2 Rx/Tx packet ratio out of range"
oid2desc[33555.2.10.13]="RipEX::trpHwIn - HW input in the alarm state"
oid2desc[33555.2.10.14]="RipEX::trpHotStby - Modem becomes active in a Hot-Standby mode"
oid2desc[33555.2.10.15]="RipEX::trpBpath - Backup path state has been changed"
oid2desc[33555.2.10.16]="RipEX::trpBpathAlt - Alternative path state has been changed"
oid2desc[33555.2.10.17]="RipEX::trpUnitReady - Unit ready signal has changed"
oid2desc[33555.2.10.18]="RipEX::trpNomadOffline - Nomadic remote device is offline"

# M!DGE, MG102i
oid2desc[33555.10.100.0.10.0.10]="MG::system-shutdown - Indicates a system shutdown"
oid2desc[33555.10.100.0.20.0.20]="MG::vpn-down-trap - Indicates a VPN connection deactivation"
oid2desc[33555.10.100.0.21.0.21]="MG::vpn-up-trap - Indicates a VPN connection activation"
oid2desc[33555.10.100.0.30.0.30]="MG::wwan-rssi-low - The WWAN RSSI is below the specified threshold"

oid2desc[33555.10.100.0.101.0.101]="MG::WAN link came UP"
oid2desc[33555.10.100.0.102.0.102]="MG::WAN link went DOWN"

oid2desc[33555.10.100.0.201.0.201]="MG::DIO IN1 turned ON"
oid2desc[33555.10.100.0.202.0.202]="MG::DIO IN1 turned OFF"
oid2desc[33555.10.100.0.203.0.203]="MG::DIO IN2 turned ON"
oid2desc[33555.10.100.0.204.0.204]="MG::DIO IN2 turned OFF"
oid2desc[33555.10.100.0.205.0.205]="MG::DIO OUT1 turned ON"
oid2desc[33555.10.100.0.206.0.206]="MG::DIO OUT1 turned OFF"
oid2desc[33555.10.100.0.207.0.207]="MG::DIO OUT2 turned ON"
oid2desc[33555.10.100.0.208.0.208]="MG::DIO OUT2 turned OFF"

oid2desc[33555.10.100.0.301.0.301]="MG::GPS signal is available"
oid2desc[33555.10.100.0.302.0.302]="MG::GPS signal is NOT available"

oid2desc[33555.10.100.0.401.0.401]="MG::OpenVPN connection came UP"
oid2desc[33555.10.100.0.402.0.402]="MG::OpenVPN connection went DOWN"
oid2desc[33555.10.100.0.403.0.403]="MG::IPsec connection came UP"
oid2desc[33555.10.100.0.404.0.404]="MG::IPsec connection went DOWN"
oid2desc[33555.10.100.0.406.0.406]="MG::PPTP connection came UP"
oid2desc[33555.10.100.0.407.0.407]="MG::PPTP connection went DOWN"
oid2desc[33555.10.100.0.408.0.408]="MG::Dial-In connection came UP"
oid2desc[33555.10.100.0.409.0.409]="MG::Dial-In connection went DOWN"
oid2desc[33555.10.100.0.410.0.410]="MG::Mobile IP connection came UP"
oid2desc[33555.10.100.0.411.0.411]="MG::Mobile IP conneciton went DOWN"
oid2desc[33555.10.100.0.412.0.412]="MG::GRE connection came UP"
oid2desc[33555.10.100.0.413.0.413]="MG::GRE connection went DOWN"

oid2desc[33555.10.100.0.501.0.501]="MG::User login failed"
# oid2desc[33555.10.100.0.502.0.502]="MG::User login succeeded"
# oid2desc[33555.10.100.0.503.0.503]="MG::User logged out"
oid2desc[33555.10.100.0.504.0.504]="MG::System reboot has been triggered"
oid2desc[33555.10.100.0.505.0.505]="MG::System has been started"
oid2desc[33555.10.100.0.506.0.506]="MG::test event"
# oid2desc[33555.10.100.0.507.0.507]="MG::SDK has started"
# oid2desc[33555.10.100.0.508.0.508]="MG::System time has been updated"
oid2desc[33555.10.100.0.509.0.509]="MG::System poweroff has been triggered"

#oid2desc[33555.10.100.0.601.0.601]="MG::SMS has been sent"
#oid2desc[33555.10.100.0.602.0.602]="MG::SMS has not been sent"
oid2desc[33555.10.100.0.603.0.603]="MG::SMS has been received"
#oid2desc[33555.10.100.0.604.0.604]="MG::SMS report has been received"

#oid2desc[33555.10.100.0.701.0.701]="MG::A voice call is coming in"
#oid2desc[33555.10.100.0.702.0.702]="MG::Outgoing voice call is being established"

#oid2desc[33555.10.100.0.802.0.801]="MG::Dynamic DNS update succeeded"
oid2desc[33555.10.100.0.802.0.802]="MG::Dynamic DNS update failed"

#oid2desc[33555.10.100.0.901.0.901]="MG::USB storage device has been added"
#oid2desc[33555.10.100.0.902.0.902]="MG::USB storage device has been removed"
#oid2desc[33555.10.100.0.903.0.903]="MG::USB Ethernet device has been added"
#oid2desc[33555.10.100.0.904.0.904]="MG::USB Ethernet device has been removed"
#oid2desc[33555.10.100.0.905.0.905]="MG::USB serial device has been added"
#oid2desc[33555.10.100.0.906.0.906]="MG::USB serial device has ben removed"

oid2desc[33555.10.100.0.802.0.1001]="MG::System is now master router"
oid2desc[33555.10.100.0.802.0.1002]="MG::System is now backup router"

# RAy1-10 
oid2desc[33555.1.10.0.1]="RacomRay::airDisconnect - Air line disconnected"
oid2desc[33555.1.10.0.2]="RacomRay::airConnect - Air line connected after being disconnected"
oid2desc[33555.1.10.0.3]="RacomRay::airWdog - Air watch dog"
oid2desc[33555.1.10.0.4]="RacomRay::tempAlarm - Temperature exceeded the threshold"
oid2desc[33555.1.10.0.5]="RacomRay::powerAlarm - Power voltage is out of thresholds"
oid2desc[33555.1.10.0.6]="RacomRay::memoryAlarm - Memory use exceeded the threshold"
oid2desc[33555.1.10.0.7]="RacomRay::rssAlarm - RSS exceeded the threshold"
oid2desc[33555.1.10.0.8]="RacomRay::snrAlarm - SNR exceeded the threshold"
oid2desc[33555.1.10.0.9]="RacomRay::berAlarm - BER exceeded the threshold"
oid2desc[33555.1.10.0.10]="RacomRay::rfPowerFail - RF Power amplifier failure"
oid2desc[33555.1.10.0.11]="RacomRay::peerEthLinkDown - Peer station ethernet link Up/Down"

# RAy1-11,17,24
oid2desc[33555.1.10.1]="RacomRay::airDisconnect - Air line disconnected"
oid2desc[33555.1.10.2]="RacomRay::airConnect - Air line connected after being disconnected"
oid2desc[33555.1.10.3]="RacomRay::airWdog - Air watch dog"
oid2desc[33555.1.10.4]="RacomRay::tempAlarm - Temperature exceeded the threshold"
oid2desc[33555.1.10.5]="RacomRay::powerAlarm - Power voltage is out of thresholds"
oid2desc[33555.1.10.6]="RacomRay::memoryAlarm - Memory use exceeded the threshold"
oid2desc[33555.1.10.7]="RacomRay::rssAlarm - RSS exceeded the threshold"
oid2desc[33555.1.10.8]="RacomRay::snrAlarm - SNR exceeded the threshold"
oid2desc[33555.1.10.9]="RacomRay::berAlarm - BER exceeded the threshold"
oid2desc[33555.1.10.10]="RacomRay::rfPowerFail - RF Power amplifier failure"
oid2desc[33555.1.10.11]="RacomRay::peerEthLinkDown - Peer station ethernet link Up/Down"

# RAy2, two different versions
oid2desc[33555.1.11.1]="RacomRay::tr2TemperatureAlarm - Temperature exceeded the threshold"
oid2desc[33555.1.11.2]="RacomRay::tr2VoltageLowAlarm - Supply voltage below minimal threshold"
oid2desc[33555.1.11.3]="RacomRay::tr2VoltageHighAlarm - Supply voltage above maximal threshold"
oid2desc[33555.1.11.4]="RacomRay::tr2RssAlarm - RSS exceeded the threshold"
oid2desc[33555.1.11.5]="RacomRay::tr2SnrAlarm - SNR exceeded the threshold"
oid2desc[33555.1.11.6]="RacomRay::tr2BerAlarm - BER exceeded the threshold"
oid2desc[33555.1.11.7]="RacomRay::tr2AirConnectDisconnect - Air line disconnected"
oid2desc[33555.1.11.8]="RacomRay::tr2AirConnectDisconnect - Air line disconnected"
oid2desc[33555.1.11.9]="RacomRay::tr2Eth1LinkDown - Peer station Ethernet 1 link Up/Down"
oid2desc[33555.1.11.10]="RacomRay::tr2Eth2LinkDown - Peer station Ethernet 2 link Up/Down"
oid2desc[33555.1.11.11]="RacomRay::tr2RfPowerFail - RF Power amplifier failure"
oid2desc[33555.1.11.12]="RacomRay::tr2NetBitrate - Air speed below threshold"
oid2desc[33555.1.11.13]="RacomRay::tr2WifiOn - WiFi Host Access Point is on"

oid2desc[33555.1.11.0.1]="RacomRay::tr2TemperatureAlarm - Temperature exceeded the threshold"
oid2desc[33555.1.11.0.2]="RacomRay::tr2VoltageLowAlarm - Supply voltage below minimal threshold"
oid2desc[33555.1.11.0.3]="RacomRay::tr2VoltageHighAlarm - Supply voltage above maximal threshold"
oid2desc[33555.1.11.0.4]="RacomRay::tr2RssAlarm - RSS exceeded the threshold"
oid2desc[33555.1.11.0.5]="RacomRay::tr2SnrAlarm - SNR exceeded the threshold"
oid2desc[33555.1.11.0.6]="RacomRay::tr2BerAlarm - BER exceeded the threshold"
oid2desc[33555.1.11.0.7]="RacomRay::tr2AirConnectDisconnect - Air line disconnected"
oid2desc[33555.1.11.0.8]="RacomRay::tr2AirConnectDisconnect - Air line disconnected"
oid2desc[33555.1.11.0.9]="RacomRay::tr2Eth1LinkDown - Peer station Ethernet 1 link Up/Down"
oid2desc[33555.1.11.0.10]="RacomRay::tr2Eth2LinkDown - Peer station Ethernet 2 link Up/Down"
oid2desc[33555.1.11.0.11]="RacomRay::tr2RfPowerFail - RF Power amplifier failure"
oid2desc[33555.1.11.0.12]="RacomRay::tr2NetBitrate - Air speed below threshold"
oid2desc[33555.1.11.0.13]="RacomRay::tr2WifiOn - WiFi Host Access Point is on"

# set the right KEY parameter
case $racomTrapOid in
        33555.2.10.1) KEY="trpRss";;
        33555.2.10.2) KEY="trpDq";;
        33555.2.10.5) KEY="trpTxLost";;
        33555.2.10.6) KEY="trpUcc";;
        33555.2.10.7) KEY="trpTemp";;
        33555.2.10.8) KEY="trpRfpwr";;
        33555.2.10.9) KEY="trpVswr";;
        33555.2.10.10) KEY="trpEthPr";;
        33555.2.10.11) KEY="trpCom1Pr";;
        33555.2.10.12) KEY="trpCom2Pr";;
        33555.2.10.13) KEY="trpHwIn";;
        33555.2.10.14) KEY="trpHotStby";;
	33555.2.10.15) KEY="trpBpath";;
	33555.2.10.16) KEY="trpBpathAlt";;
	33555.2.10.17) KEY="trpUnitReady";;
	33555.2.10.18) KEY="trpNomadOffline";;
	33555.10.100.0.10.0.10) KEY="trpMgShut";;
	33555.10.100.0.20.0.20) KEY="trpMgVpn";;
	33555.10.100.0.21.0.21) KEY="trpMgVpn";;
	33555.10.100.0.30.0.30) KEY="trpMgRssi";;
	33555.10.100.0.101.0.101) KEY="wanLinkDown";;
	33555.10.100.0.102.0.102) KEY="wanLinkDown";;
	33555.10.100.0.201.0.201) KEY="dioIn1";;
	33555.10.100.0.202.0.202) KEY="dioIn1";;
	33555.10.100.0.203.0.203) KEY="dioIn2";;
	33555.10.100.0.204.0.204) KEY="dioIn2";;
	33555.10.100.0.205.0.205) KEY="dioOut1";;
	33555.10.100.0.206.0.206) KEY="dioOut1";;
	33555.10.100.0.207.0.207) KEY="dioOut2";;
	33555.10.100.0.208.0.208) KEY="dioOut2";;
	33555.10.100.0.301.0.301) KEY="gps";;
	33555.10.100.0.302.0.302) KEY="gps";;
	33555.10.100.0.401.0.401) KEY="openvpnDown";;
	33555.10.100.0.402.0.402) KEY="openvpnDown";;
	33555.10.100.0.403.0.403) KEY="ipsecDown";;
	33555.10.100.0.404.0.404) KEY="ipsecDown";;
	33555.10.100.0.406.0.406) KEY="pptpDown";;
	33555.10.100.0.407.0.407) KEY="pptpDown";;
	33555.10.100.0.408.0.408) KEY="dialinDown";;
	33555.10.100.0.409.0.409) KEY="dialinDown";;
	33555.10.100.0.410.0.410) KEY="mobileIpDown";;
	33555.10.100.0.411.0.411) KEY="mobileIpDown";;
	33555.10.100.0.412.0.412) KEY="greDown";;
	33555.10.100.0.413.0.413) KEY="greDown";;
	33555.10.100.0.501.0.501) KEY="userLoginFailed";;
	33555.10.100.0.504.0.504) KEY="reboot";;
	33555.10.100.0.505.0.505) KEY="systemStart";;
	33555.10.100.0.506.0.506) KEY="test";;
	33555.10.100.0.603.0.603) KEY="smsReceived";;
	33555.10.100.0.802.0.802) KEY="dyndnsFailed";;
        33555.1.10.0.1) KEY="airDisconnect";;
        33555.1.10.0.2) KEY="airConnect";;
        33555.1.10.0.3) KEY="airWdog";;
        33555.1.10.0.4) KEY="tempAlarm";;
        33555.1.10.0.5) KEY="powerAlarm";;
        33555.1.10.0.6) KEY="memoryAlarm";;
        33555.1.10.0.7) KEY="rssAlarm";;
        33555.1.10.0.8) KEY="snrAlarm";;
        33555.1.10.0.9) KEY="berAlarm";;
        33555.1.10.0.10) KEY="rfPowerFail";;
        33555.1.10.0.11) KEY="peerEthLinkDown";;
        33555.1.10.1) KEY="airDisconnect";;
        33555.1.10.2) KEY="airConnect";;
        33555.1.10.3) KEY="airWdog";;
        33555.1.10.4) KEY="tempAlarm";;
        33555.1.10.5) KEY="powerAlarm";;
        33555.1.10.6) KEY="memoryAlarm";;
        33555.1.10.7) KEY="rssAlarm";;
        33555.1.10.8) KEY="snrAlarm";;
        33555.1.10.9) KEY="berAlarm";;
        33555.1.10.10) KEY="rfPowerFail";;
        33555.1.10.11) KEY="peerEthLinkDown";;
        33555.1.11.1) KEY="tr2TemperatureAlarm";;
        33555.1.11.2) KEY="tr2VoltageLowAlarm";;
        33555.1.11.3) KEY="tr2VoltageHighAlarm";;
        33555.1.11.4) KEY="tr2RssAlarm";;
        33555.1.11.5) KEY="tr2SnrAlarm";;
        33555.1.11.6) KEY="tr2BerAlarm";;
        33555.1.11.7) KEY="tr2AirDisconnect";;
        33555.1.11.8) KEY="tr2AirDisconnect";;
        33555.1.11.9) KEY="tr2Eth1LinkDown";;
        33555.1.11.10) KEY="tr2Eth2LinkDown";;
        33555.1.11.11) KEY="tr2RfPowerFail";;
 	33555.1.11.12) KEY="tr2NetBitrate";;
	33555.1.11.13) KEY="tr2WifiOn";;
        33555.1.11.0.1) KEY="tr2TemperatureAlarm";;
        33555.1.11.0.2) KEY="tr2VoltageLowAlarm";;
        33555.1.11.0.3) KEY="tr2VoltageHighAlarm";;
        33555.1.11.0.4) KEY="tr2RssAlarm";;
        33555.1.11.0.5) KEY="tr2SnrAlarm";;
        33555.1.11.0.6) KEY="tr2BerAlarm";;
        33555.1.11.0.7) KEY="tr2AirDisconnect";;
        33555.1.11.0.8) KEY="tr2AirDisconnect";;
        33555.1.11.0.9) KEY="tr2Eth1LinkDown";;
        33555.1.11.0.10) KEY="tr2Eth2LinkDown";;
        33555.1.11.0.11) KEY="tr2RfPowerFail";;
 	33555.1.11.0.12) KEY="tr2NetBitrate";;
	33555.1.11.0.13) KEY="tr2WifiOn";;
        *) KEY="snmptraps";;
esac

# If the received trap is DQ or RSS then change the KEY to KEY+RemoteIP
# The remote IP must be without "" signs (first and last character)
if [ "$KEY" = "trpDq" ] || [ "$KEY" = "trpRss" ]; then
	ipOrPnValue=${ipOrPnValue:1:(${#ipOrPnValue}-2)}	
	KEY=$KEY$ipOrPnValue
	echo "New KEY = $KEY" >> ${LOGFILE}
fi

# LOGGING TRAP INFO
echo "UPTIME: $uptime" >> ${LOGFILE}
echo "Host: $host, Key: $KEY" >> ${LOGFILE}

# 2019-01-08 TM: RipEX traps testing
if [[ "$alarmValue" == "inactive" ]] || [[ "$alarmValue" == "off" ]]; then
	alarmValue="OFF"
elif [[ "$alarmValue" == "active" ]] || [[ "$alarmValue" == "on" ]]; then
	alarmValue="ON"
fi

# 2017-08-02
# Declare an array with the RipEX Alternative Path states
# To enable mapping, add mibs +/usr/share/snmp/mibs/RACOM-RipEX-1.0.4.0.mib to /etc/snmp/snmp.conf
value2state[0]="Unknown"
value2state[1]="Up"
value2state[2]="Down"

# Explanation
# 2019-01-08 TM: RipEX traps testing
if [ $wvValue = "down" ]; then
	wvValue="DOWN"
elif [ $wvValue = "up" ]; then
	wvValue="UP"
fi

# Create a string with all needed information - can be easily edited
# See the comments to know which if/then/else branch corresponds to which trap

if [ "$NUMBER_OF_VARS" -eq 3 ]; then
	if [[ "$racomTrapOid" == *33555.10.100.0* ]]; then
		# M!DGE, MG102i traps
		str="KEY: $KEY, Description: ${oid2desc[$racomTrapOid]}";
	else
		# RipEX - trpRss, trpDq
		str="ALARM: $alarmValue, WatchedValue VALUE: $wvValue, Remote IP address: $ipOrPnValue";
	fi
elif [ "$NUMBER_OF_VARS" -eq 5 ]; then
	if [[ "$racomTrapOid" == *33555.1.10.0* ]]; then
                # RAy10
                str="Description: ${oid2desc[$racomTrapOid]}, ALARM value: $alarmValue";
	else
		# RipEX - trpBpath, trpBpathAlt
		str="Peer IP address: $alarmValue, Symbolic name: $wvValue, Priority number: $ipOrPnValue, Gateway IP address: $bpGwValue, Current state: $altPSValue";
	fi
else
	if [ "$KEY" == "trpHotStby" ]; then
		# RipEX - trpHotStby
		str="Active HotStandBy unit name: $wvValue, serial number: $alarmValue";
	fi

	if [[ "$racomTrapOid" == *33555.1.10* ]]; then
		# RAy1 - these traps will stay active only defined number of seconds in the Zabbix front-end. RAy does not send "OK" traps. 
		str="Description: ${oid2desc[$racomTrapOid]}, ALARM value: $alarmValue";
	fi

	if [[ "$racomTrapOid" == *33555.1.11* ]]; then
		# RAy2
		str="ALARM: $wvValue, WatchedValue value: $alarmValue, Description: ${oid2desc[$racomTrapOid]}";
	else 
		if [[ "$racomTrapOid" == *33555.2.10.17* ]] || [[ "$racomTrapOid" == *33555.2.10.18* ]]; then
			# RipEX - trpUnitReady, trpNomadOffline
			str="ALARM: $alarmValue, UPTIME: $uptime";
		else
			# RipEX - trpVswr, trpUcc, ...
			str="ALARM: $alarmValue, WatchedValue VALUE: $wvValue";
		fi
	fi
fi

# Send the information to the Zabbix server
$ZABBIX_SENDER -z $ZABBIX_SERVER -p $ZABBIX_PORT -s "$host" -k "$KEY" -o "$str"
echo "$ZABBIX_SENDER -z $ZABBIX_SERVER -p $ZABBIX_PORT -s $host -k $KEY -o $str" >> ${LOGFILE}
