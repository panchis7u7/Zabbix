#!/bin/bash

backupStatus=`/usr/bin/ssh -p $3 -i $2 admin@$1 'export PATH=$PATH:/usr/sbin; /usr/cli_bin/cli_cnf_textfile_get'`

serialNumber=`/usr/bin/ssh -p $3 -i $2 admin@$1 'export PATH=$PATH:/usr/sbin; /usr/cli_bin/cli_status_show' | grep Serial | cut -f3 -d' '`
ethIP=`/usr/bin/ssh -p $3 -i $2 admin@$1 'export PATH=$PATH:/usr/sbin; /usr/cli_bin/cli_status_show' | grep "Eth LAN IP" | cut -f4 -d' '`

joiner="_"
file="_cnf_backup.txt"
backupFile=$ethIP$joiner$serialNumber$file

copyStatus=`scp -i $2 -P $3 admin@$1:/rrrwmnt/home/admin/config.txt /home/zabbix/configuration-backup/ripex/$backupFile`

echo `/usr/bin/ls -l /home/zabbix/configuration-backup/ripex/$backupFile`
